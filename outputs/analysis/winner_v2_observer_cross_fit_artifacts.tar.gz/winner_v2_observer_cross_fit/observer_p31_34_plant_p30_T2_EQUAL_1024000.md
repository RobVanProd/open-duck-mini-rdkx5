# Ground-Up Policy Evaluation

status: `PASS_GAIT_EMERGENCE_CHECKPOINT`
execution: `CPU_ONLY`

## Aggregate

- runs: `4`
- moving_runs: `3`
- zero_command_runs: `1`
- moving_emergence_pass: `True`
- zero_command_finite_recorded: `True`
- checkpoint_emergence_pass: `True`

## Runs

| command x | seed | evaluator | emergence | termination | dx m | transitions | reasons |
|---:|---:|---|---|---|---:|---:|---|
| 0.0 | 167931544 | `PASS_CANDIDATE_SIM_GATE` | `True` | `duration_complete` | -0.007895044769157736 | 0 | none |
| 0.074 | 167931544 | `PASS_CANDIDATE_SIM_GATE` | `True` | `duration_complete` | 1.1630476220347918 | 148 | none |
| 0.077 | 167931544 | `PASS_CANDIDATE_SIM_GATE` | `True` | `duration_complete` | 1.1450781340594405 | 160 | none |
| 0.08 | 167931544 | `PASS_CANDIDATE_SIM_GATE` | `True` | `duration_complete` | 1.1990845413162605 | 135 | none |
